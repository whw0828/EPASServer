﻿namespace Dapper.Tests
{
    public class SomeType
    {
        public int A { get; set; }
        public string B { get; set; }
    }
}
